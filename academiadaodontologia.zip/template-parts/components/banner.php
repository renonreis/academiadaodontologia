<section class="banner-info banner-info--center position-relative py-5">
  <div class="container">
    <div class="row py-4">
      <div>
        <h2>A comodidade do Ensino On-line aliada à interação com o professor possível no Ensino Presencial.</h2>
        <a href="#escolha-o-seu-plano" class="btn btn-lg btn-outline-light stretched-link">Comece agora</a>
      </div>
    </div>
  </div>
</section>